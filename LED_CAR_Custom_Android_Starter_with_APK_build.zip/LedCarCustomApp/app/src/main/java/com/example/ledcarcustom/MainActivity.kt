package com.example.ledcarcustom

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private data class LedDevice(val name: String, val address: String, val rssi: Int)

private val welcomeNames = listOf(
    "Rainbow Sweep", "Meteor Tail", "Comet Run", "Breathing Glow", "Waterfall",
    "Dual Wave", "Color Pulse", "Sequential Start", "Aurora Flow", "Sparkle Trail"
).flatMap { base -> (1..10).map { n -> "$base ${n.toString().padStart(2, '0')}" } }

class MainActivity : ComponentActivity() {
    private var scanCallback: ScanCallback? = null
    private val foundDevices = mutableStateListOf<LedDevice>()
    private var scanning by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF28C8FF),
                    background = Color(0xFF07172E),
                    surface = Color(0xFF102746)
                )
            ) {
                LedCarApp(
                    devices = foundDevices,
                    scanning = scanning,
                    onScan = { requestAndScan() },
                    onStop = { stopScan() }
                )
            }
        }
    }

    private fun requestAndScan() {
        val required = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else startBleScan()
    }

    private val permissionLauncher by lazy {
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.all { it }) startBleScan()
        }
    }

    @Suppress("MissingPermission")
    private fun startBleScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter ?: return
        if (!adapter.isEnabled) return
        val scanner = adapter.bluetoothLeScanner ?: return
        foundDevices.clear()
        scanning = true
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val name = try { device.name ?: result.scanRecord?.deviceName ?: "Unknown BLE device" }
                            catch (_: SecurityException) { "BLE device" }
                val item = LedDevice(name, device.address, result.rssi)
                val old = foundDevices.indexOfFirst { it.address == item.address }
                if (old >= 0) foundDevices[old] = item else foundDevices.add(item)
            }
            override fun onScanFailed(errorCode: Int) { scanning = false }
        }
        scanCallback = callback
        scanner.startScan(callback)
    }

    @Suppress("MissingPermission")
    private fun stopScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        scanCallback?.let { manager.adapter?.bluetoothLeScanner?.stopScan(it) }
        scanCallback = null
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        super.onDestroy()
    }
}

@Composable
private fun LedCarApp(
    devices: List<LedDevice>,
    scanning: Boolean,
    onScan: () -> Unit,
    onStop: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("Welcome 100") }
    var selectedEffect by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(50f) }
    var brightness by remember { mutableFloatStateOf(50f) }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF073A5C), Color(0xFF071329))))
            .padding(16.dp)
    ) {
        Text("LED CAR CUSTOM", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Bluetooth • Welcome animation studio", color = Color(0xFF9CCCEB), fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Welcome 100", "Bluetooth").forEach { tab ->
                FilterChip(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    label = { Text(tab) }
                )
            }
        }
        if (selectedTab == "Welcome 100") {
            Spacer(Modifier.height(12.dp))
            EffectPreview(selectedEffect)
            Text(welcomeNames[selectedEffect], color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Text("Effect ${selectedEffect + 1} / 100 • Preview only", color = Color(0xFF9CCCEB), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { selectedEffect = (selectedEffect + 99) % 100 }) { Text("Previous") }
                Button(onClick = { selectedEffect = (selectedEffect + 1) % 100 }) { Text("Next effect") }
            }
            Text("Speed: ${speed.toInt()}", color = Color.White)
            Slider(value = speed, onValueChange = { speed = it }, valueRange = 1f..100f)
            Text("Brightness: ${brightness.toInt()}", color = Color.White)
            Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 1f..100f)
            Text("These are app-side visual previews. Sending effects to the controller is not enabled until its BLE protocol is verified.",
                color = Color(0xFFFFD18A), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text("All 100 effects", color = Color.White, fontWeight = FontWeight.Bold)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(welcomeNames.indices.toList()) { index ->
                    Row(
                        Modifier.fillMaxWidth().background(
                            if (selectedEffect == index) Color(0xFF174E78) else Color(0xFF102746),
                            RoundedCornerShape(10.dp)
                        ).clickable { selectedEffect = index }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${index + 1}. ${welcomeNames[index]}", color = Color.White, modifier = Modifier.weight(1f))
                        if (selectedEffect == index) Text("SELECTED", color = Color(0xFF58D6FF), fontSize = 10.sp)
                    }
                }
            }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("Nearby Bluetooth devices", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onScan, enabled = !scanning) { Text("Scan") }
                OutlinedButton(onClick = onStop, enabled = scanning) { Text("Stop") }
            }
            Text(if (scanning) "Scanning…" else "Scan for your LED CAR controller.", color = Color(0xFF9CCCEB))
            if (devices.isEmpty()) Text("No devices listed yet.", color = Color.LightGray, modifier = Modifier.padding(top = 12.dp))
            LazyColumn {
                items(devices) { device ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text(device.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("${device.address}  •  RSSI ${device.rssi}", color = Color(0xFF9CCCEB), fontSize = 12.sp)
                    }
                    HorizontalDivider(color = Color(0xFF31516C))
                }
            }
            Text("BLE scan only. Connection, GATT services and write commands are intentionally not implemented yet.",
                color = Color(0xFFFFD18A), fontSize = 12.sp)
        }
    }
}

@Composable
private fun EffectPreview(index: Int) {
    val transition = rememberInfiniteTransition(label = "preview")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    val colors = listOf(Color.Red, Color.Green, Color.Blue, Color.Cyan, Color.Magenta, Color.Yellow)
    Canvas(
        Modifier.fillMaxWidth().height(150.dp)
            .background(Color(0xFF06101F), RoundedCornerShape(16.dp)).padding(12.dp)
    ) {
        val count = 28
        for (i in 0 until count) {
            val x = (i + 0.5f) * size.width / count
            val shift = ((i / 4f + phase * 5f + index * 0.17f) % colors.size).toInt()
            val color = colors[shift]
            val wave = (kotlin.math.sin((i * 0.45f + phase * 6.28f + index) .toDouble()).toFloat() + 1f) / 2f
            val radius = 4f + wave * 8f
            drawCircle(color.copy(alpha = 0.35f), radius = radius * 1.8f, center = Offset(x, size.height / 2))
            drawCircle(color, radius = radius, center = Offset(x, size.height / 2))
        }
    }
}
