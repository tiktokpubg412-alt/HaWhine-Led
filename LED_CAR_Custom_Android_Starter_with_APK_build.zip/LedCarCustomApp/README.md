# LED CAR Custom (starter)

Android Studio starter project for the LED CAR Custom app.

## Included
- Kotlin + Jetpack Compose UI
- 100 named welcome-effect entries
- Animated on-screen effect preview (visual simulation only)
- Android BLE device scan, including device name/address/RSSI
- Speed and brightness UI controls

## Important hardware limitation
This starter does **not** send lighting commands to the controller yet. The screenshots identify the app profile as `LED CAR 01-XXXX / RGB DMX` and show a DMX list ending at mode 210, but they do not reveal the controller's BLE GATT service UUID, characteristic UUID, packet format, or whether firmware accepts user-defined patterns.

Before enabling writes:
1. Identify the exact controller PCB and microcontroller marking.
2. Read its BLE GATT services/characteristics.
3. Capture/inspect the app's BLE command protocol with permission and without changing firmware.
4. Verify whether the controller can execute custom frames or only built-in mode IDs.
5. Preserve a verified original firmware backup if the chip supports readback.

Do not flash guessed firmware or send arbitrary bytes to the controller. Incorrect commands can cause unpredictable output or damage.

## Build
Open this folder in Android Studio (recent version), let Gradle sync, then run on an Android phone. BLE scan permissions are requested at runtime. Bluetooth must be enabled.
